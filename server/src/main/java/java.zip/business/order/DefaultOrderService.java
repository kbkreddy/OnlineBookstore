package business.order;

import api.ApiException;
import api.ApiExceptionHandler;
import business.BookstoreDbException;
import business.JdbcUtils;
import business.book.Book;
import business.book.BookDao;
import business.cart.ShoppingCart;
import business.cart.ShoppingCartItem;
import business.category.CategoryDao;
import business.customer.Customer;
import business.customer.CustomerDao;
import business.customer.CustomerForm;


import java.sql.Connection;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class DefaultOrderService implements OrderService {

	private BookDao bookDao;
	private CategoryDao categoryDao;
	private OrderDao orderDao;
	private LineItemDao lineItemDao;

	private CustomerDao customerDao;
	public void setBookDao(BookDao bookDao) {
		this.bookDao = bookDao;
	}
	public void setCategoryDao(CategoryDao categoryDao) {
		this.categoryDao = categoryDao;
	}

	public void setOrderDao(OrderDao orderDao) {
		this.orderDao = orderDao;
	}

	public void setLineItemDao(LineItemDao lineItemDao) {
		this.lineItemDao = lineItemDao;
	}

	public void setCustomerDao(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}
	@Override
	public OrderDetails getOrderDetails(long orderId) {
		Order order = orderDao.findByOrderId(orderId);
		Customer customer = customerDao.findByCustomerId(order.getCustomerId());
		List<LineItem> lineItems = lineItemDao.findByOrderId(orderId);
		List<Book> books = lineItems
				.stream()
				.map(lineItem -> bookDao.findByBookId(lineItem.getBookId()))
				.collect(Collectors.toList());
		return new OrderDetails(order, customer, lineItems, books);
	}

	@Override
    public long placeOrder(CustomerForm customerForm, ShoppingCart cart) {

		validateCustomer(customerForm);
		validateCart(cart);

		try (Connection connection = JdbcUtils.getConnection()) {
			Date date = getDate(
					customerForm.getCcExpiryMonth(),
					customerForm.getCcExpiryYear());
			return performPlaceOrderTransaction(
					customerForm.getName(),
					customerForm.getAddress(),
					customerForm.getPhone(),
					customerForm.getEmail(),
					customerForm.getCcNumber(),
					date, cart, connection);
		} catch (SQLException e) {
			throw new BookstoreDbException("Error during close connection for customer order", e);
		}
	}

	private Date  getDate(String monthString, String yearString) {
		DateFormat dateFormat = new SimpleDateFormat("MM-yyyy");
		Date inputDate;
		try {
			inputDate = dateFormat.parse(monthString + "-" + yearString);
		} catch (Exception e) {
			throw new ApiException("date parsing failed", e);
		}
		return inputDate; // TODO Implement this correctly
	}

	private void validateCustomer(CustomerForm customerForm)  {

    	String name = customerForm.getName();
		String phoneNumber = customerForm.getPhone();
		String ccNumber = customerForm.getCcNumber();
		String email = customerForm.getEmail();
		String address = customerForm.getAddress();

		if (name == null || name.equals("") || name.length() > 45) {
			throw new ApiException.InvalidParameter("Invalid name field");
		}


		if (address == null || address.equals("") || address.length() > 45) {
			throw new ApiException.InvalidParameter("Invalid address field");
		}

		String cleanedPhoneNumber = phoneNumber.replaceAll("[^+\\d]", "");
		if (cleanedPhoneNumber.length()!=10) {
			throw new ApiException.InvalidParameter("Invalid phone number field");
		}

		String ccNumberCleaned = ccNumber.replaceAll("[^+\\d]", "");
		if (ccNumberCleaned.length() > 16 || ccNumberCleaned.length()<14) {
			throw new ApiException.InvalidParameter("Invalid credit card number field");
		}
		String EMAIL_PATTERN =
				"^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
						+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		//TODO EMail pending
		if (!Pattern.matches(EMAIL_PATTERN, email)) {
			throw new ApiException.InvalidParameter("Invalid email field");
		}

		Date currDate = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(currDate);
		if (expiryDateIsInvalid(customerForm.getCcExpiryMonth(), customerForm.getCcExpiryYear())) {
			throw new ApiException.InvalidParameter("Invalid expiry date ");
		}
	}

	private boolean expiryDateIsInvalid(String ccExpiryMonth, String ccExpiryYear) {

		// TODO: return true when the provided month/year is before the current month/yeaR
//		// HINT: Use Integer.parseInt and the YearMonth class

		Date currDate = new Date();
		Calendar cal = Calendar.getInstance();
		cal.setTime(currDate);
		if ( cal.get(Calendar.YEAR) > Integer.parseInt(ccExpiryYear) ){
			return true;
		} else if (cal.get(Calendar.YEAR)== Integer.parseInt(ccExpiryYear)) {
			return cal.get(Calendar.MONTH)+1 >  Integer.parseInt(ccExpiryMonth);
		}
		return false;
	}


	private void validateCart(ShoppingCart cart) {

		if (cart.getItems().size() <= 0) {
			throw new ApiException.InvalidParameter("Cart is empty.");
		}

		cart.getItems().forEach(item-> {
			if (item.getQuantity() < 0 || item.getQuantity() > 99) {
				throw new ApiException.InvalidParameter("Invalid quantity");
			}
			Book databaseBook = bookDao.findByBookId(item.getBookId());
			if ( item.getBookForm().getPrice() != databaseBook.getPrice()){
				throw new ApiException.InvalidParameter("Invalid price");
			}
			if (item.getBookForm().getCategoryId() != databaseBook.getCategoryId()) {
				throw new ApiException.InvalidParameter("Invalid category");
			}


			// TODO: complete the required validations
		});
	}
	private long performPlaceOrderTransaction(
			String name, String address, String phone,
			String email, String ccNumber, Date date,
			ShoppingCart cart, Connection connection) {
		Logger logger = Logger.getLogger(ApiExceptionHandler.class.getName());
		try {
			connection.setAutoCommit(false);
			logger.log(Level.ALL,"TESTING1");
			long customerId = customerDao.create(
					connection, name, address, phone, email,
					ccNumber, date);
			logger.log(Level.ALL,"TESTING3");

			System.out.println(customerId);
			long customerOrderId = orderDao.create(
					connection,
					cart.getComputedSubtotal() + cart.getSurcharge(),
					generateConfirmationNumber(), customerId);
			System.out.println(customerId);
			logger.log(Level.ALL,"TESTING2");

			for (ShoppingCartItem item : cart.getItems()) {
				lineItemDao.create(connection, customerOrderId,
						item.getBookId(), item.getQuantity());
			}
			connection.commit();
			return customerOrderId;
		} catch (Exception e) {
			try {
				connection.rollback();
			} catch (SQLException e1) {
				throw new BookstoreDbException("Failed to roll back transaction", e1);
			}
			return 0;
		}
	}

	private int generateConfirmationNumber() {
		Random random = new Random();
		return random.nextInt(999999999); // To do use generate a random number
	}

}
